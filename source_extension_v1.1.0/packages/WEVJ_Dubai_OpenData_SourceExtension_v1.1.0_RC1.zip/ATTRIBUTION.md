# Attribution and reuse

## Dubai government open-data layers

Source data in this package are attributed to their issuing authorities and to Data Dubai / Dubai Pulse. The package relies on the official Open Data classification shown by the source portal and the Dubai Open Data reuse framework retained in the project provenance. Dataset-specific terms take precedence if they are more restrictive.

- Roads and Transport Authority (RTA), Public Transportation Stations: https://www.gslb.dubaipulse.gov.ae/data/rta-registers/rta_public_transportation_stations-open
- Roads and Transport Authority (RTA), Bus Stop Details: https://gslb.dubaipulse.gov.ae/data/rta-bus/rta_bus_stop_details-open
- Dubai Statistics Center / Dubai Data and Statistics Establishment, Population by Community: https://www.gslb.dubaipulse.gov.ae/data/dsc-statistics/dsc_population_by_community-open

Suggested attribution: Source data: [Issuing Authority], [Dataset Title], Data Dubai / Dubai Pulse, retained study snapshot. Reused under the applicable Dubai open-data terms. Processing and interpretation are those of the authors and do not imply endorsement by the Government of Dubai or the issuing authority.

OpenStreetMap / Geofabrik material is not redistributed in this package. Google-derived raw material is excluded.
