# WEVJ Dubai EV Charging Siting — Open-Data Source Extension v1.1.0 RC1

This release candidate is a public-source traceability extension for the published WEVJ paper (DOI 10.3390/wevj17080411). It does not modify the Version of Record or any scientific score, rank, weight, model structure, dataset definition, or conclusion.

## Included source material

Only source objects that passed the current redistribution/provenance gate are included:

1. RTA Public Transportation Stations retained snapshot (137 rows).
2. Dubai Statistics / DDSE Population by Community retained snapshot (1,130 rows).
3. A deterministic, one-row-per-stop derivative of the retained RTA Bus Stop Details snapshot (4,505 stops). The 451,712-row raw audit snapshot is not redistributed in RC1; the transformation script is included.

## Not included

The following are intentionally excluded from RC1: raw Google-derived outputs; the mixed-source 7,410-candidate archive; the historical DEWA raw charger CSV because exact retained bytes were not recovered; the historical Dubai Municipality community KML because exact retained bytes were not recovered; historical Metro/Tram KML snapshots whose file-level resource provenance is not fully closed; parking/estimated-population/population-cluster snapshots whose exact retained resource identity remains open; and the Geofabrik PBF, which remains link-only under ODbL attribution.

## Claim boundary

This extension improves public source traceability and partial source-to-output regeneration only. It is not observed-demand validation, feeder-capacity validation, power-flow analysis, financial feasibility analysis, construction approval, or a final deployment plan.

## Scientific anchors preserved

- 7,410 admitted candidate/amenity records.
- 5,097 inside-boundary candidates.
- Baseline leader: S1421/Boonmax.
- Official-DEWA source leader: S3473.
- Necessary top-15 core: 12.
- Possible top-15 envelope: 18.
- TOPSIS top-15 overlap: 0/15.
- Road-network top-15 overlap: 14/15.
- Official-DEWA top-15 overlap: 13/15.

RC1 is a preparation artifact and must not be cited as a final Zenodo version until a v1.1.0 release is explicitly published.
