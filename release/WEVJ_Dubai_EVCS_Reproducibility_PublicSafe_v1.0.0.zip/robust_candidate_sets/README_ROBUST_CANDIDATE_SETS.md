# Robust Candidate Sets and Bounded Spatial Evidence Outputs

This folder contains derived, coordinate-conscious and coordinate-free diagnostic outputs for the source-conditioned robustness extension revision. The files support the new source-conditioned robust candidate-set analysis, TOPSIS mechanism audit, DEWA 2x2 source/weight decomposition, source/date/unit ontology, and bounded spatial context summaries.

These outputs do not replace the baseline NI-EA score, weights, rankings, or model structure. Transit, community, parking, DEWA regulatory, and OSM-derived layers are used only for post-screening context and source documentation unless explicitly listed as a baseline or sensitivity input in the manuscript.

Key files:
- `candidate_rank_matrix_available_scenarios.csv`: candidate ranks for available scenario families.
- `k_stability_profile_by_family.csv`: K-stability summaries for K = 5, 10, 15, 25, 50, and 100.
- `necessary_possible_topK_core_summary.csv`: necessary and possible top-K candidate-set sizes.
- `family_balanced_rank_acceptability_top100.csv`: finite-scenario family-balanced top-K acceptability summary.
- `topsis_top50_mechanism_audit.csv`: TOPSIS intermediate audit for the top ranked TOPSIS alternatives.
- `source_date_unit_ontology.csv`: machine-readable source/date/unit ontology.
- `scenario_registry.csv`: scenario registry used for reproducibility documentation.

- `external_spatial_plausibility_top50_vs_remaining.csv`: post-screening comparison of baseline top-50 candidates against the remaining retained candidates using only variables not included in NI-EA scoring.
- `external_spatial_plausibility_source_fields.csv`: source-field list for the external spatial plausibility table.


## Road-network sentinel rule
For full-order retention, the matched road-network comparison uses the 5,090 candidates passing the routable-snap quality gate. The released 5,097-row rank matrix retains the seven excluded candidates with road-network rank 5098, an out-of-top-tier sentinel value. These candidates therefore contribute zero to top-K membership for the road-network scenario in reconstructed robust-set and family-balanced acceptability calculations.
