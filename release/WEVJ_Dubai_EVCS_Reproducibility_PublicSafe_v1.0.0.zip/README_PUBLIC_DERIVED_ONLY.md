# Public derived-only supplementary package

## Scope
This public supplementary package contains coordinate-free derived outputs, reproducibility checks, sensitivity summaries, evidence-gate documentation, and audit notes. It does not redistribute raw candidate coordinates, raw third-party charger or candidate/amenity layers, Google-derived labels, full crosswalks, or controlled source inputs.

## Construct boundary
The first criterion is a candidate-derived local amenity/activity-density baseline: a self-excluded local count derived from the same admitted candidate/amenity source set used to form the candidate universe. It is not observed charging demand, an independent demand layer, an external exposure layer, or validation evidence.

## Included robustness material
- Method ablation, interaction, weighting, activity-density-radius, coverage-definition, Pareto, road-network, and official-coordinate source-sensitivity summaries.
- Candidate-representation robustness summaries and descriptive top-field enrichment outputs.
- DEWA source-change mechanism summary and reconstruction checks.
- Reproducibility verification record and public provenance manifest.

## Controlled material and remaining limit
The full source-coordinate inputs, per-candidate mechanism-audit output, source hashes, and complete grid outputs are retained in a controlled editor/reviewer audit package, subject to applicable source terms. This public package does not itself provide a package-local raw-source rerun path; that remains an open reproducibility requirement.

Citable diagnostic strengthening additions:
- `derived_outputs/full_pareto_monotonicity_audit_summary.csv`
- `derived_outputs/full_pareto_monotonicity_audit_full5097.csv`
- `derived_outputs/interaction_effect_audit_summary.csv`
- `derived_outputs/interaction_effect_audit_full5097.csv`

These files are derived from the released coordinate-free candidate metric table. They do not add new criteria, coordinates, source layers, weights, rankings, or implementation claims.


Manuscript supplementary labels are mapped to package files in `Supplementary_Item_Map.md`.
