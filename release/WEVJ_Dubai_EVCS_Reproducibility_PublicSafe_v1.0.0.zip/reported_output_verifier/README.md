# Reported-output verifier

Run from the Supplementary root:

```bash
python reported_output_verifier/verify_reported_outputs.py --package-root .
```

## What it verifies

From released coordinate-free derived metric files, the verifier recalculates and checks:

- baseline normalization, CRITIC weights, NI-EA components, scores, and ranks;
- WSM, Einstein aggregation, TOPSIS, and no-interaction comparator summaries;
- all 63 interaction scenarios and all three stated weighting scenarios;
- matched road-network and Euclidean scores/ranks over the 5,090-candidate matched population;
- official-DEWA source sensitivity and all four geometry/weight mechanism configurations;
- top-50 Pareto dominance fields;
- structural consistency of regular-grid outputs, grid weights, and detailed top-field enrichment aggregation; and
- structural consistency of activity-density-radius, coverage-definition, and full-candidate summary tables.

## What it does not verify

It does **not** regenerate the original coordinates, activity-density counts, boundary admission, charger or substation distances, OSM road routes, DEWA raw coordinates, regular-grid node fields, or source hashes from raw primary layers. It is therefore **reported-output verification**, not a full source-to-result rerun.

`verification_result.csv` is generated at runtime and intentionally excluded from the static SHA-256 manifest.
