#!/usr/bin/env python3
"""Recalculate and audit the reported outputs from coordinate-free derived files.

This verifier is deliberately NOT a raw-source GIS regeneration pipeline. It cannot recreate
candidate records, self-excluded activity-density counts, charger/substation geometry, road
routes, DEWA source inputs, regular grids, or external source hashes from primary files.
It verifies calculations that are possible from the released derived metric fields and checks
internal aggregation of detailed public grid/enrichment audit outputs.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import kendalltau, spearmanr

TOL = 1e-10
ROUND_TOL = 5.1e-6


def rank_desc(values: np.ndarray) -> np.ndarray:
    """Descending stable ordinal ranks; exact ties preserve the predefined row order."""
    values = np.asarray(values, dtype=float)
    order = np.argsort(-values, kind="mergesort")
    ranks = np.empty(values.size, dtype=int)
    ranks[order] = np.arange(1, values.size + 1)
    return ranks


def critic_weights(x: np.ndarray) -> np.ndarray:
    sd = np.std(x, axis=0, ddof=1)
    corr = np.corrcoef(x, rowvar=False)
    q = sd * np.sum(1.0 - corr, axis=1)
    return q / np.sum(q)


def ni_ea(x: np.ndarray, weights: np.ndarray, kappa: float = 0.12,
          gamma: float = 1.0, alpha: float = 0.5) -> tuple[np.ndarray, ...]:
    linear = x @ weights
    interaction = x[:, 0] * x[:, 2]
    z = linear + kappa * interaction
    psi = np.exp(gamma * z)
    nonlinear = (psi - psi.min()) / (psi.max() - psi.min())
    u = x * weights[None, :]
    einstein = (u[:, 0] + u[:, 1]) / (1.0 + u[:, 0] * u[:, 1])
    einstein = (einstein + u[:, 2]) / (1.0 + einstein * u[:, 2])
    score = alpha * nonlinear + (1.0 - alpha) * einstein
    return linear, interaction, z, nonlinear, einstein, score


def normalise_from_raw(activity: np.ndarray, coverage_distance: np.ndarray,
                       grid_distance: np.ndarray) -> np.ndarray:
    activity = np.asarray(activity, dtype=float)
    coverage_distance = np.asarray(coverage_distance, dtype=float)
    grid_distance = np.asarray(grid_distance, dtype=float)
    spans = np.array([
        activity.max() - activity.min(),
        coverage_distance.max() - coverage_distance.min(),
        grid_distance.max() - grid_distance.min(),
    ])
    if np.any(spans <= 0.0):
        raise ValueError(f"non-positive criterion span: {spans.tolist()}")
    return np.column_stack([
        (activity - activity.min()) / spans[0],
        (coverage_distance - coverage_distance.min()) / spans[1],
        (grid_distance.max() - grid_distance) / spans[2],
    ])


def metrics(reference: np.ndarray, candidate: np.ndarray) -> dict[str, object]:
    rr = rank_desc(reference)
    cr = rank_desc(candidate)
    return {
        "spearman": float(spearmanr(rr, cr).statistic),
        "kendall": float(kendalltau(rr, cr).statistic),
        "top1": int(np.argmin(cr)),
        "top10": int(len(set(np.where(rr <= 10)[0]) & set(np.where(cr <= 10)[0]))),
        "top15": int(len(set(np.where(rr <= 15)[0]) & set(np.where(cr <= 15)[0]))),
        "top25": int(len(set(np.where(rr <= 25)[0]) & set(np.where(cr <= 25)[0]))),
        "top50": int(len(set(np.where(rr <= 50)[0]) & set(np.where(cr <= 50)[0]))),
        "changed": int(np.count_nonzero(rr != cr)),
        "max_move": int(np.max(np.abs(rr - cr))),
    }


def check(condition: bool, name: str, detail: str, records: list[dict[str, str]]) -> None:
    records.append({"check": name, "status": "PASS" if condition else "FAIL", "detail": detail})


def close(a: np.ndarray | float, b: np.ndarray | float, tol: float = TOL) -> bool:
    aa, bb = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
    return bool(np.nanmax(np.abs(aa - bb)) <= tol)


def manifest_exclusions(path: str) -> bool:
    return (
        path == "SHA256_manifest.csv"
        or path == "reported_output_verifier/verification_result.csv"
        or "/__pycache__/" in path
        or path.endswith(".pyc")
    )


def verify_manifest(root: Path, records: list[dict[str, str]]) -> None:
    manifest = root / "SHA256_manifest.csv"
    rows = list(csv.DictReader(manifest.open(encoding="utf-8")))
    errors = []
    listed = set()
    for row in rows:
        rel = row["relative_path"]
        listed.add(rel)
        if manifest_exclusions(rel):
            errors.append(f"excluded-listed:{rel}")
            continue
        p = root / rel
        if not p.is_file():
            errors.append(f"missing:{rel}")
            continue
        digest = hashlib.sha256(p.read_bytes()).hexdigest()
        if digest != row["sha256"]:
            errors.append(f"hash:{rel}")
        if int(row["bytes"]) != p.stat().st_size:
            errors.append(f"size:{rel}")
    # static package files must be represented; generated verifier output is intentionally excluded.
    unlisted = []
    for p in root.rglob("*"):
        if p.is_file():
            rel = p.relative_to(root).as_posix()
            if not manifest_exclusions(rel) and rel not in listed:
                unlisted.append(rel)
    check(not errors and not unlisted, "supplementary manifest", "; ".join(errors + [f"unlisted:{x}" for x in unlisted]) if (errors or unlisted) else f"{len(rows)} static files verified", records)


def verify_baseline(derived: Path, records: list[dict[str, str]]) -> tuple[pd.DataFrame, np.ndarray, np.ndarray, np.ndarray]:
    df = pd.read_csv(derived / "full5097_candidate_scores_no_coordinates.csv")
    check(len(df) == 5097 and df["site_id"].is_unique, "baseline population and site identifiers", f"rows={len(df)}, unique_ids={df['site_id'].nunique()}", records)
    x = normalise_from_raw(
        df["candidate_derived_activity_density_count_1km_self_excluded"].to_numpy(),
        df["nearest_combined_charger_km"].to_numpy(),
        df["nearest_substation_km"].to_numpy(),
    )
    stored_x = df[["activity_density_norm", "coverage_gap_norm", "grid_access_norm"]].to_numpy(float)
    check(close(x, stored_x), "baseline direct min-max normalization", f"max abs diff={np.max(np.abs(x-stored_x)):.3e}", records)
    w = critic_weights(x)
    weights = pd.read_csv(derived / "weights.csv")
    stored_w = weights.loc[weights["weight_method"] == "CRITIC", ["w_activity_density", "w_coverage_gap", "w_grid_access"]].iloc[0].to_numpy(float)
    check(close(w, stored_w), "baseline CRITIC weights", f"max abs diff={np.max(np.abs(w-stored_w)):.3e}", records)
    linear, interaction, z, nonlinear, einstein, score = ni_ea(x, w)
    for name, calc, stored in [
        ("baseline linear component", linear, df["L_CRITIC_full5097"].to_numpy(float)),
        ("baseline activity-density-grid interaction", interaction, df["I_ActivityDensityGrid"].to_numpy(float)),
        ("baseline interaction-adjusted component", z, df["Z_kappa0p12"].to_numpy(float)),
        ("baseline nonlinear component", nonlinear, df["N_Nonlinear_minmaxPsi"].to_numpy(float)),
        ("baseline Einstein component", einstein, df["Einstein_E"].to_numpy(float)),
        ("baseline NI-EA score", score, df["NI_EA_score_full5097"].to_numpy(float)),
    ]:
        check(close(calc, stored), name, f"max abs diff={np.max(np.abs(calc-stored)):.3e}", records)
    stored_rank = df["full5097_rank"].to_numpy(int)
    calc_rank = rank_desc(score)
    check(np.array_equal(calc_rank, stored_rank), "baseline rank field", f"exact={np.array_equal(calc_rank, stored_rank)}", records)
    return df, x, score, w


def verify_ablation(derived: Path, x: np.ndarray, baseline: np.ndarray, w: np.ndarray, records: list[dict[str, str]]) -> None:
    summary = pd.read_csv(derived / "ablation_method_comparison.csv", encoding="utf-8-sig")
    linear, _, _, _, einstein, _ = ni_ea(x, w)
    r = x / np.sqrt(np.sum(x ** 2, axis=0))
    v = r * w[None, :]
    pos, neg = v.max(axis=0), v.min(axis=0)
    dpos = np.sqrt(np.sum((v-pos)**2, axis=1))
    dneg = np.sqrt(np.sum((v-neg)**2, axis=1))
    topsis = dneg/(dpos+dneg)
    _, _, _, _, _, no_int = ni_ea(x, w, kappa=0.0)
    methods = {"WSM": linear, "Einstein aggregation": einstein, "TOPSIS": topsis, "NI-EA without interaction (kappa=0)": no_int}
    for _, row in summary.iterrows():
        candidate = methods[row["method"]]
        m = metrics(baseline, candidate)
        expected = [row["spearman_all5097"], row["kendall_tau_all5097_approx"], row["top10_overlap"], row["top15_overlap"], row["top25_overlap"], row["changed_rank_count_all"], row["max_abs_rank_change"]]
        observed = [m["spearman"], m["kendall"], m["top10"], m["top15"], m["top25"], m["changed"], m["max_move"]]
        ok = close(expected[:2], observed[:2]) and expected[2:] == observed[2:]
        check(ok, f"ablation {row['method']}", f"observed={observed}", records)


def verify_interaction_grid(derived: Path, x: np.ndarray, baseline: np.ndarray, w: np.ndarray, ids: np.ndarray, records: list[dict[str, str]]) -> None:
    table = pd.read_csv(derived / "kappa_gamma_alpha_sensitivity.csv")
    failures = 0
    for _, row in table.iterrows():
        *_, s = ni_ea(x, w, float(row["kappa_lambda_times_rho"]), float(row["gamma"]), float(row["alpha"]))
        m = metrics(baseline, s)
        expected = [row["spearman_vs_baseline"], row["kendall_tau_vs_baseline"], row["top1_site_id"], row["top10_overlap"], row["top15_overlap"], row["top25_overlap"], row["changed_rank_count_all"], row["max_abs_rank_change"]]
        observed = [m["spearman"], m["kendall"], ids[m["top1"]], m["top10"], m["top15"], m["top25"], m["changed"], m["max_move"]]
        if not (close(expected[:2], observed[:2]) and expected[2:] == observed[2:]):
            failures += 1
    check(failures == 0, "63-scenario interaction grid", f"failed rows={failures}/63", records)


def verify_weights(derived: Path, x: np.ndarray, baseline: np.ndarray, ids: np.ndarray, records: list[dict[str, str]]) -> None:
    table = pd.read_csv(derived / "weight_sensitivity.csv")
    failures = 0
    for _, row in table.iterrows():
        w = row[["w_activity_density", "w_coverage_gap", "w_grid_access"]].to_numpy(float)
        *_, s = ni_ea(x, w)
        m = metrics(baseline, s)
        expected = [row["spearman_vs_baseline"], row["kendall_tau_vs_baseline"], row["top1_site_id"], row["top10_overlap"], row["top15_overlap"], row["top25_overlap"], row["changed_rank_count_all"], row["max_abs_rank_change"]]
        observed = [m["spearman"], m["kendall"], ids[m["top1"]], m["top10"], m["top15"], m["top25"], m["changed"], m["max_move"]]
        if not (close(expected[:2], observed[:2]) and expected[2:] == observed[2:]):
            failures += 1
    check(failures == 0, "three weighting scenarios from stated weights", f"failed rows={failures}/3", records)


def verify_road(derived: Path, records: list[dict[str, str]]) -> None:
    df = pd.read_csv(derived / "road_network_matched_scores_no_coordinates.csv")
    raw_a = df["candidate_derived_activity_density_count_1km_self_excluded"].to_numpy()
    raw_grid = df["nearest_substation_km"].to_numpy()
    x_e = normalise_from_raw(raw_a, df["nearest_combined_charger_km"].to_numpy(), raw_grid)
    x_r = normalise_from_raw(raw_a, df["route_distance_to_nearest_combined_charger_km"].to_numpy(), raw_grid)
    check(len(df) == 5090 and df["site_id"].is_unique, "matched-road population and identifiers", f"rows={len(df)}, unique_ids={df['site_id'].nunique()}", records)
    check(close(x_e[:, 1], df["euclidean_coverage_norm"].to_numpy(float)), "matched-road Euclidean coverage normalization", f"max abs diff={np.max(np.abs(x_e[:,1]-df['euclidean_coverage_norm'].to_numpy(float))):.3e}", records)
    check(close(x_r[:, 1], df["road_network_coverage_norm"].to_numpy(float)), "matched-road routing coverage normalization", f"max abs diff={np.max(np.abs(x_r[:,1]-df['road_network_coverage_norm'].to_numpy(float))):.3e}", records)
    _, _, _, _, _, s_e = ni_ea(x_e, critic_weights(x_e))
    _, _, _, _, _, s_r = ni_ea(x_r, critic_weights(x_r))
    check(close(s_e, df["euclidean_NI_EA_score"].to_numpy(float)), "matched-road Euclidean NI-EA score", f"max abs diff={np.max(np.abs(s_e-df['euclidean_NI_EA_score'].to_numpy(float))):.3e}", records)
    check(close(s_r, df["road_network_NI_EA_score"].to_numpy(float)), "matched-road route NI-EA score", f"max abs diff={np.max(np.abs(s_r-df['road_network_NI_EA_score'].to_numpy(float))):.3e}", records)
    check(np.array_equal(rank_desc(s_e), df["euclidean_full_matched_rank"].to_numpy(int)), "matched-road Euclidean rank", "exact rank check", records)
    check(np.array_equal(rank_desc(s_r), df["road_network_full_matched_rank"].to_numpy(int)), "matched-road route rank", "exact rank check", records)


def verify_official_and_mechanism(derived: Path, base_df: pd.DataFrame, x_base: np.ndarray, base_score: np.ndarray, w_base: np.ndarray, records: list[dict[str, str]]) -> None:
    off = pd.read_csv(derived / "official_source_sensitivity_no_coordinates.csv")
    merged = base_df[["site_id", "candidate_derived_activity_density_count_1km_self_excluded", "nearest_substation_km", "full5097_rank", "NI_EA_score_full5097"]].merge(off, on="site_id", how="left", validate="one_to_one")
    check(len(merged) == 5097 and merged["official_dewa_plus_fixed_osm_nearest_km"].notna().all(), "official-source metric alignment", f"rows={len(merged)}, complete_official_distances={merged['official_dewa_plus_fixed_osm_nearest_km'].notna().sum()}", records)
    check(close(merged["nearest_combined_charger_km"], merged["baseline_combined_recomputed_euclidean_km"], tol=5.1e-5), "official-source baseline geometry reconstruction", f"max abs diff={np.max(np.abs(merged['nearest_combined_charger_km']-merged['baseline_combined_recomputed_euclidean_km'])):.3e}", records)
    check(close(merged["official_dewa_plus_fixed_osm_nearest_km"]-merged["nearest_combined_charger_km"], merged["official_delta_vs_baseline_stored_km"], tol=ROUND_TOL), "official-source distance delta field", f"max abs diff={np.max(np.abs((merged['official_dewa_plus_fixed_osm_nearest_km']-merged['nearest_combined_charger_km'])-merged['official_delta_vs_baseline_stored_km'])):.3e}", records)
    check(np.array_equal(merged["full5097_rank"].to_numpy(int), merged["baseline_rank"].to_numpy(int)), "official-source baseline rank alignment", "exact baseline rank check", records)
    check(close(merged["NI_EA_score_full5097"], merged["baseline_score"], tol=ROUND_TOL), "official-source baseline score alignment", f"max abs diff={np.max(np.abs(merged['NI_EA_score_full5097']-merged['baseline_score'])):.3e}", records)
    x_off = normalise_from_raw(merged["candidate_derived_activity_density_count_1km_self_excluded"], merged["official_dewa_plus_fixed_osm_nearest_km"], merged["nearest_substation_km"])
    w_off = critic_weights(x_off)
    *_, b_score = ni_ea(x_off, w_base)
    *_, c_score = ni_ea(x_base, w_off)
    *_, d_score = ni_ea(x_off, w_off)
    check(close(d_score, merged["official_snapshot_source_sensitivity_score"], tol=ROUND_TOL), "official-source NI-EA score", f"max abs diff={np.max(np.abs(d_score-merged['official_snapshot_source_sensitivity_score'])):.3e}", records)
    check(np.array_equal(rank_desc(d_score), merged["official_snapshot_source_sensitivity_rank"].to_numpy(int)), "official-source NI-EA rank", "exact official-source rank check", records)
    summary = pd.read_csv(derived / "dewa_source_change_mechanism_audit_summary.csv")
    scenarios = {
        "A_baseline_geometry_baseline_weights": (base_score, w_base),
        "B_official_geometry_baseline_weights": (b_score, w_base),
        "C_baseline_geometry_official_weights": (c_score, w_off),
        "D_official_geometry_official_weights": (d_score, w_off),
    }
    ids = merged["site_id"].to_numpy()
    for name, (score, weights) in scenarios.items():
        row = summary.loc[summary["scenario"] == name].iloc[0]
        ranks = rank_desc(score)
        mm = metrics(base_score, score)
        i1421 = int(np.where(ids == "S1421")[0][0])
        i3473 = int(np.where(ids == "S3473")[0][0])
        observed = [ids[np.argmin(ranks)], ranks[i1421], ranks[i3473], score[i1421], score[i3473], mm["spearman"], mm["kendall"], mm["top10"], mm["top15"], mm["top25"], mm["top50"], mm["changed"], mm["max_move"]]
        expected = [row["leader_site_id"], row["S1421_rank"], row["S3473_rank"], row["S1421_score"], row["S3473_score"], row["rank_spearman_vs_baseline"], row["rank_kendall_vs_baseline"], row["top10_overlap_vs_baseline"], row["top15_overlap_vs_baseline"], row["top25_overlap_vs_baseline"], row["top50_overlap_vs_baseline"], row["changed_ranks_vs_baseline"], row["max_abs_rank_movement_vs_baseline"]]
        ok = expected[0] == observed[0] and expected[1:3] == observed[1:3] and close(expected[3:7], observed[3:7], tol=ROUND_TOL) and expected[7:] == observed[7:]
        check(ok, f"DEWA mechanism scenario {name[0]}", f"leader={observed[0]}, S1421/S3473 ranks={observed[1:3]}", records)
    checks = pd.read_csv(derived / "dewa_mechanism_reconstruction_checks.csv")
    check((checks["status"] == "PASS").all() and len(checks) == 2, "stored DEWA mechanism reconstruction record", f"rows={len(checks)}, statuses={checks['status'].tolist()}", records)


def verify_pareto(derived: Path, base_df: pd.DataFrame, records: list[dict[str, str]]) -> None:
    p = pd.read_csv(derived / "pareto_top50_no_coordinates.csv")
    base_top = base_df.sort_values("full5097_rank", kind="mergesort").head(50)
    check(len(p) == 50 and np.array_equal(p["site_id"].to_numpy(), base_top["site_id"].to_numpy()), "Pareto top-50 membership and order", "exact baseline top-50 check", records)
    x = p[["activity_density_norm", "coverage_norm", "grid_norm"]].to_numpy(float)
    dom_count = []
    for i in range(len(p)):
        dom = np.all(x >= x[i], axis=1) & np.any(x > x[i], axis=1)
        dom[i] = False
        dom_count.append(int(dom.sum()))
    expected_count = p["number_of_dominators"].to_numpy(int)
    expected_yes = np.where(p["dominated_by_any_candidate"].astype(str).str.lower().eq("yes"), 1, 0)
    check(np.array_equal(np.asarray(dom_count), expected_count), "Pareto dominator counts within reported top-50", f"max abs diff={np.max(np.abs(np.asarray(dom_count)-expected_count))}", records)
    check(np.array_equal((np.asarray(dom_count) > 0).astype(int), expected_yes), "Pareto dominated flags", f"nondominated={(np.asarray(dom_count)==0).sum()}, dominated={(np.asarray(dom_count)>0).sum()}", records)
    check((p["dominance_rank_violation"].astype(str).str.lower() == "no").all(), "Pareto dominance-rank violation field", "all reported as No", records)


def verify_grid_and_enrichment(derived: Path, records: list[dict[str, str]]) -> None:
    grid = pd.read_csv(derived / "candidate_representation_robustness_summary.csv")
    check(len(grid) == 12 and set(grid["grid_spacing_m"]) == {500, 1000, 2000} and grid.groupby("grid_spacing_m").size().eq(4).all(), "grid robustness construction structure", f"rows={len(grid)}, offsets_per_spacing={grid.groupby('grid_spacing_m').size().to_dict()}", records)
    expected_nodes = np.ceil(grid["grid_points"].to_numpy(float) * 0.01).astype(int)
    check(np.array_equal(grid["grid_top_1pct_n"].to_numpy(int), expected_nodes), "grid top-1% node counts", "ceiling(1% of grid points) exact", records)
    gw = pd.read_csv(derived / "grid_population_critic_weight_summary.csv")
    grid_keys = set(map(tuple, grid[["grid_spacing_m", "offset_x_m", "offset_y_m"]].to_numpy()))
    gw_keys = set(map(tuple, gw[["grid_spacing_m", "offset_x_m", "offset_y_m"]].to_numpy()))
    check(grid_keys == gw_keys and len(gw) == 12, "grid weight rows align with grid constructions", f"grid_rows={len(grid)}, weight_rows={len(gw)}", records)
    check(close(gw[["w_activity_density", "w_coverage_gap", "w_grid_access"]].sum(axis=1).to_numpy(float), np.ones(len(gw))), "grid CRITIC weight sums", "all sums=1 within tolerance", records)

    audit = pd.read_csv(derived / "candidate_representation_top_field_enrichment_audit.csv")
    summary = pd.read_csv(derived / "candidate_representation_top_field_enrichment_summary.csv")
    ranges = pd.read_csv(derived / "candidate_representation_top_field_enrichment_range_summary.csv")
    check(len(audit) == 72 and audit.groupby(["grid_spacing_m", "offset_x_m", "offset_y_m", "top_field_percent"]).size().eq(2).all(), "top-field detailed audit structure", f"rows={len(audit)}, two groups per construction/threshold", records)
    expected_field_nodes = np.ceil(audit["grid_points"].to_numpy(float) * audit["top_field_percent"].to_numpy(float)).astype(int)
    check(np.array_equal(audit["grid_top_field_nodes"].to_numpy(int), expected_field_nodes), "top-field node counts", "ceiling(percent x grid points) exact", records)
    rows=[]
    keys=["grid_spacing_m","offset_x_m","offset_y_m","top_field_percent"]
    for key,g in audit.groupby(keys, sort=False):
        a = g.set_index("candidate_group")
        top=a.loc["baseline_top50"]
        other=a.loc["other_5047_candidates"]
        rows.append(dict(zip(keys,key),
            top50_median_distance_m=top["median_distance_to_top_field_m"],
            other_median_distance_m=other["median_distance_to_top_field_m"],
            median_distance_ratio_other_over_top50=other["median_distance_to_top_field_m"]/top["median_distance_to_top_field_m"],
            top50_share_within_1km=top["share_within_1km"],
            other_share_within_1km=other["share_within_1km"],
            top50_share_within_2km=top["share_within_2km"],
            other_share_within_2km=other["share_within_2km"],
            within_2km_difference_pp=100*(top["share_within_2km"]-other["share_within_2km"]),
            within_1km_difference_pp=100*(top["share_within_1km"]-other["share_within_1km"])))
    calc=pd.DataFrame(rows).sort_values(keys).reset_index(drop=True)
    reported=summary.sort_values(keys).reset_index(drop=True)
    numeric=[c for c in calc.columns if c not in keys]
    check(len(calc)==len(reported) and close(calc[numeric].to_numpy(float),reported[numeric].to_numpy(float),tol=1e-9), "top-field enrichment summary aggregation", f"rows={len(calc)}, max diff={np.max(np.abs(calc[numeric].to_numpy(float)-reported[numeric].to_numpy(float))):.3e}", records)
    rr=[]
    for pct,g in reported.groupby("top_field_percent", sort=True):
        rr.append({
            "top_field_percent":pct,
            "top50_median_distance_m_min":g["top50_median_distance_m"].min(), "top50_median_distance_m_max":g["top50_median_distance_m"].max(),
            "other_median_distance_m_min":g["other_median_distance_m"].min(), "other_median_distance_m_max":g["other_median_distance_m"].max(),
            "ratio_min":g["median_distance_ratio_other_over_top50"].min(), "ratio_max":g["median_distance_ratio_other_over_top50"].max(),
            "top50_within1km_min":g["top50_share_within_1km"].min(), "top50_within1km_max":g["top50_share_within_1km"].max(),
            "other_within1km_min":g["other_share_within_1km"].min(), "other_within1km_max":g["other_share_within_1km"].max(),
            "top50_within2km_min":g["top50_share_within_2km"].min(), "top50_within2km_max":g["top50_share_within_2km"].max(),
            "other_within2km_min":g["other_share_within_2km"].min(), "other_within2km_max":g["other_share_within_2km"].max(),
        })
    rr=pd.DataFrame(rr).sort_values("top_field_percent").reset_index(drop=True)
    ranges=ranges.sort_values("top_field_percent").reset_index(drop=True)
    numeric=[c for c in rr.columns if c!="top_field_percent"]
    check(len(rr)==len(ranges) and close(rr[numeric].to_numpy(float),ranges[numeric].to_numpy(float),tol=1e-9), "top-field enrichment range-summary aggregation", f"rows={len(rr)}, max diff={np.max(np.abs(rr[numeric].to_numpy(float)-ranges[numeric].to_numpy(float))):.3e}", records)


def verify_summary_tables(derived: Path, base_df: pd.DataFrame, w_base: np.ndarray, records: list[dict[str, str]]) -> None:
    radius = pd.read_csv(derived / "activity_density_radius_sensitivity.csv")
    cover = pd.read_csv(derived / "coverage_definition_robustness.csv")
    for label, table, baseline_label in [("activity-density radius", radius, "1 km baseline"), ("coverage definition", cover, "Nearest distance")]:
        weights=table[["critic_weight_activity_density","critic_weight_coverage_gap","critic_weight_grid_access"]].sum(axis=1).to_numpy(float)
        check((table["available"].astype(str).str.lower()=="yes").all() and close(weights,np.ones(len(table)),tol=1e-9), f"{label} summary structure and weight sums", f"rows={len(table)}, all available, weights sum to 1", records)
        b=table.loc[table.iloc[:,0].astype(str)==baseline_label].iloc[0]
        ok=close(b[["critic_weight_activity_density","critic_weight_coverage_gap","critic_weight_grid_access"]].to_numpy(float),w_base,tol=ROUND_TOL) and b["top1_site_id"]=="S1421"
        check(ok, f"{label} baseline summary row", f"baseline leader={b['top1_site_id']}", records)
    fc=pd.read_csv(derived / "full_candidate_robustness_summary.csv")
    d=dict(zip(fc["metric"],fc["value"]))
    check(str(d.get("Eligible inside-Dubai candidates used in full-candidate analysis"))=="5097", "full-candidate robustness summary population", f"reported={d.get('Eligible inside-Dubai candidates used in full-candidate analysis')}", records)
    check(close([float(d.get("CRITIC weight activity density")),float(d.get("CRITIC weight coverage gap")),float(d.get("CRITIC weight grid access"))],w_base,tol=TOL), "full-candidate robustness summary CRITIC weights", "exact baseline weight check", records)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", default=".", help="Supplementary package root")
    args = parser.parse_args()
    root = Path(args.package_root).resolve()
    derived = root / "derived_outputs"
    records: list[dict[str, str]] = []
    try:
        verify_manifest(root, records)
        df, x, baseline, w = verify_baseline(derived, records)
        verify_ablation(derived, x, baseline, w, records)
        verify_interaction_grid(derived, x, baseline, w, df["site_id"].to_numpy(), records)
        verify_weights(derived, x, baseline, df["site_id"].to_numpy(), records)
        verify_road(derived, records)
        verify_official_and_mechanism(derived, df, x, baseline, w, records)
        verify_pareto(derived, df, records)
        verify_grid_and_enrichment(derived, records)
        verify_summary_tables(derived, df, w, records)
    except Exception as exc:
        check(False, "verifier execution", repr(exc), records)
    out = root / "reported_output_verifier" / "verification_result.csv"
    with out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["check", "status", "detail"])
        writer.writeheader()
        writer.writerows(records)
    failures = [r for r in records if r["status"] != "PASS"]
    print(f"{len(records)-len(failures)} PASS; {len(failures)} FAIL; wrote {out}")
    return 1 if failures else 0

if __name__ == "__main__":
    raise SystemExit(main())
