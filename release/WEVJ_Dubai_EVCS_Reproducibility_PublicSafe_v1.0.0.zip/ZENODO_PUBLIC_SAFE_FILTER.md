# Zenodo/GitHub public-safe packaging note

This archive is a packaging-only public companion derived from the final supplementary ZIP used for the published WEVJ article. The scientific results, scores, ranks, weights, model structure, datasets used for the published analysis, and conclusions are unchanged.

Two files from the publisher-facing supplementary ZIP are intentionally not re-published in this GitHub/Zenodo companion:

1. `robust_candidate_sets/candidate_transit_proximity_context.csv` — omitted because it contains candidate latitude/longitude fields. The public companion preserves the stated coordinate-free redistribution boundary while retaining the aggregate transit-proximity summaries.
2. `robust_candidate_sets/run_analysis.py` — omitted because it is a source-bound internal reconstruction script with absolute local paths and dependencies on controlled/raw source files that are not redistributed. It is not the public reported-output verifier identified as Script S1.

The authoritative published article and publisher-hosted Supplementary Materials remain the scientific record. The portable public verifier retained here is `reported_output_verifier/verify_reported_outputs.py`.
