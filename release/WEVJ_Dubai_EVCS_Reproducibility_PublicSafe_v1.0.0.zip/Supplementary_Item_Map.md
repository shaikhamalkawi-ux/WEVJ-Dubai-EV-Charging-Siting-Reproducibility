# Supplementary Item Map

This file maps the supplementary labels used in the manuscript to actual files and folders in this archive. The labels are organizational descriptions and do not add a new score, criterion, dataset, rank, or conclusion.

- Table S1: `Table_S1_Inspection_Subset_No_Coordinates.csv` (also provided as `Table_S1_inspection_subset15_no_coordinates.csv`) and source file `derived_outputs/inspection_subset15_no_coordinates.csv`.
- Ledger S2: `Ledger_S2_Desk_Audit_No_Coordinates.csv` (also provided as `Ledger_S2_inspection_subset_desk_audit_no_coordinates.csv`).
- File S1: coordinate-free full-candidate scores and normalized metric fields: `derived_outputs/full5097_candidate_scores_no_coordinates.csv`, `derived_outputs/weights.csv`.
- File S2: ablation, benchmark, and score-discrimination outputs: `derived_outputs/ablation_method_comparison.csv`, `derived_outputs/score_discrimination_summary.csv`, and related note files.
- File S3: interaction, weighting, activity-density-radius, and coverage-definition sensitivity outputs: `derived_outputs/kappa_gamma_alpha_sensitivity.csv`, `derived_outputs/weight_sensitivity.csv`, `derived_outputs/activity_density_radius_sensitivity.csv`, `derived_outputs/coverage_definition_robustness.csv`.
- File S4: Pareto, full-candidate Pareto-monotonicity, and interaction-effect audit outputs: `derived_outputs/pareto_top50_no_coordinates.csv`, `derived_outputs/full_pareto_monotonicity_audit_summary.csv`, `derived_outputs/full_pareto_monotonicity_audit_full5097.csv`, `derived_outputs/interaction_effect_audit_summary.csv`, `derived_outputs/interaction_effect_audit_full5097.csv`.
- File S5: matched road-network coverage sensitivity outputs: `derived_outputs/road_network_matched_scores_no_coordinates.csv` and road-network notes.
- File S6: official-DEWA source-reconciliation and source-change mechanism outputs: `derived_outputs/official_source_sensitivity_no_coordinates.csv`, `derived_outputs/dewa_source_change_mechanism_audit_summary.csv`, `robust_candidate_sets/dewa_2x2_margin_decomposition.csv`, `robust_candidate_sets/dewa_four_configuration_margin_table.csv`.
- File S7: candidate-representation, top-field enrichment, and grid-sensitivity summaries: candidate-representation files in `derived_outputs/` and `robust_candidate_sets/`.
- File S8: source/date/unit ontology, scenario registry, and public provenance records: `robust_candidate_sets/source_date_unit_ontology.csv`, `robust_candidate_sets/scenario_registry.csv`, `source_provenance_manifest_public.csv`.
- File S9: bounded spatial-context summaries and implementation-review schema: urban-context files in `robust_candidate_sets/` and all files in `implementation_review_schema/`.
- Script S1: reported-output verifier: `reported_output_verifier/verify_reported_outputs.py` with `reported_output_verifier/README.md` and `reported_output_verifier/requirements.txt`.
- README/provenance documentation: `README.md`, `README_PUBLIC_DERIVED_ONLY.md`, notes in `notes/`, and this `Supplementary_Item_Map.md`.
