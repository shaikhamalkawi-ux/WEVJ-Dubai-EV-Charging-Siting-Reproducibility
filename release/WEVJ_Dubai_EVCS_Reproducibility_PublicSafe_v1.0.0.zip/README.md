# Supplementary Materials

This public supplementary package contains reuse-safe coordinate-free derived outputs, reported-output verification scripts, robustness summaries, the 15-site inspection-subset material, provenance notes, and implementation-review field schema.

Scope: the verifier recalculates reported outputs from released coordinate-free metric fields and checks summarized grid/enrichment outputs. It is not a raw source-to-result spatial regeneration package and does not redistribute restricted third-party source exports or coordinate layers.


## Ranking-stability certificate

The file `derived_outputs/ranking_stability_certificate.csv` reports the three-level ranking-stability certificate values used in the revised manuscript. It is computed only from existing reported sensitivity outputs. It does not add a new criterion, weight, data source, score, or rank.

- notes/Interaction_Denominator_Note.md: confirms that the interaction contribution ratio denominator is nonzero for all 5,097 retained candidates.

Final no-manuscript supplementary update: derived_outputs/score_discrimination_summary.csv and notes/Score_Discrimination_Summary_Note.md were added as descriptive within-method score-separation diagnostics. No score definition, rank, candidate set, weight, model structure, dataset, or manuscript conclusion was changed.


## Manuscript supplementary item labels

The mapping from manuscript labels (Table S1, Ledger S2, Files S1-S9, Script S1, and README/provenance documentation) to actual package files is provided in `Supplementary_Item_Map.md`.
