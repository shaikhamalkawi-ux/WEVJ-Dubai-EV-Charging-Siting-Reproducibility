# Candidate-representation top-field enrichment audit

This coordinate-free audit compares the reported baseline top-50 candidates with the other 5,047 candidates by their nearest distance to the high-scoring regular-grid field reconstructed from fixed source layers. It evaluates 0.5%, 1%, and 2% grid-score fields across 12 regular-grid constructions. Results are descriptive only: no inferential tests, external validation, construction-feasibility claim, or temporal claim is made.
