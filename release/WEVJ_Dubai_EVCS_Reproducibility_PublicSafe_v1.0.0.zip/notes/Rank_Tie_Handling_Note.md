# Rank tie-handling note

All reported candidate orderings use a descending stable sort. If two scores are exactly equal, their order follows the predefined candidate-row sequence. In the released 5,097-candidate baseline, three non-top-tier score pairs are exactly tied under the released raw metric values: S5484/S7369 (ranks 2488/2489), S6177/S7384 (3363/3364), and S914/S1163 (4199/4200). No reported top-50, top-25, top-15, or leading-candidate conclusion depends on these ties.

The stable-sort convention is now stated in the Methods and implemented in the reported-output verifier. A full raw-source rerun must preserve the predefined row identity/order or supply an equivalent deterministic tiebreak rule.
