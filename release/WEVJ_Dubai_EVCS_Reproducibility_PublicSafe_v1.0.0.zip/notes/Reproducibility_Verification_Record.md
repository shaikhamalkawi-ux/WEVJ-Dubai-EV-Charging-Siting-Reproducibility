# Reproducibility Verification Record

This record is generated from the fixed-source recovery audit. It confirms the recovered candidate, candidate/amenity reference, charger, substation, and boundary layers, and records numerical reproduction of the previously reported candidate-level NI-EA score field.

The candidate-derived activity-density baseline is a self-excluded count drawn from the same admitted candidate/amenity record set used to define the candidate universe. It is not an independent demand layer, an observed charging-demand measure, or validation evidence.

The record does not certify external validation. It confirms source-record recovery and computational reproduction of the reported baseline score field. The nine documented one-count activity-density discrepancies arise only in a reconstruction check involving near-coincident/duplicate record self-exclusion bookkeeping; the fixed baseline values remain the baseline replication input. A package-local raw-source rerun remains an open reproducibility requirement.
