# International Implementation References Note

The manuscript includes a compact table of international implementation references. The references explain only the boundary between public-data screening and later implementation evidence. They do not calibrate Dubai scores, compare city performance, assess UAE compliance, or change any NI-EA score, rank, weight, dataset, or conclusion.

The manuscript cites city implementation examples (Amsterdam, Stockholm, London, and Singapore) and selected standards/regulatory references (ISO 37122, Regulation (EU) 2023/1804, IEC 61851 series, and ISO 15118 series) solely for this boundary interpretation.
