# Score-discrimination summary

This supplementary diagnostic reports within-method score separation for NI-EA, WSM, Einstein aggregation, and TOPSIS over the 5,097 retained candidates. The table reports mean score, population standard deviation, interquartile range, top-15 score range, and the rank-15/rank-16 score gap.

These values are descriptive diagnostics only. They are not used to modify any score definition, ranking, candidate set, weight, model structure, or conclusion. Scores are compared only within each method because the methods use different score scales and transformations.
