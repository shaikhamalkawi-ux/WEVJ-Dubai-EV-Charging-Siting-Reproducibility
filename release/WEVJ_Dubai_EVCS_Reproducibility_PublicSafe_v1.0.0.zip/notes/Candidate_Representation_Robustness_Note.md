# Locked-source candidate-representation robustness

This supplementary note documents a controlled robustness analysis that projects the three admitted public-data proxies onto regular grid nodes inside the same selected OSM/Nominatim Dubai boundary proxy.

The test uses only fixed baseline source layers and the exact NI-EA form and parameters. It changes no reported candidate score or rank. Each grid population recalculates its own normalization and CRITIC weights; results therefore assess spatial-pattern continuity under an alternative candidate representation, not invariance of weights, exact ranks, or construction feasibility.

Public files provide derived summary tables only. Full grid coordinates and full derived grid scores remain in the controlled audit package because the analysis depends on third-party source layers subject to applicable source terms.
