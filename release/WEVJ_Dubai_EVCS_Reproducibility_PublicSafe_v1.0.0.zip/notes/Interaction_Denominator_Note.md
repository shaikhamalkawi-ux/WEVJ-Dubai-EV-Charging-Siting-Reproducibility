# Interaction contribution denominator note

The interaction contribution ratio reported in the manuscript is defined as

ICR_i = kappa A_i G_i / (w_A A_i + w_C C_i + w_G G_i + kappa A_i G_i).

The released coordinate-free interaction-effect audit confirms that no retained candidate had a zero interaction-adjusted kernel denominator. Across the 5,097 retained candidates, the minimum denominator was 0.1524982048562514. Therefore, ICR_i is defined for all reported candidates and groups.
