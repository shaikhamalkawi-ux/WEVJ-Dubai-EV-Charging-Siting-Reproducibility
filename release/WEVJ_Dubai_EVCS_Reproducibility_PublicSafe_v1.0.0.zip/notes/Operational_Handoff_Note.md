# Operational Handoff Note

This public supplementary item provides a field schema and blank data-entry template for a later implementation-side review of the reported screening outputs.

It does **not** add a criterion, weight, equation, score, rank, construction recommendation, engineering validation, or official deployment decision.

The sequence is deliberately separated:

1. The reported NI-EA workflow screens candidates using the reported public-data proxies.
2. An controlled planning, parking, mobility, utility, safety, and/or operator review may record additional source-linked evidence outside the NI-EA model.
3. Any progression to detailed engineering study, hold, or rejection must be an controlled decision and does not amend the reported ranking.

The controlled technical handoff version containing third-party-derived candidate coordinates and labels is not included in this public package. It is retained separately and is releasable only subject to the applicable source terms and an controlled technical-review arrangement.
