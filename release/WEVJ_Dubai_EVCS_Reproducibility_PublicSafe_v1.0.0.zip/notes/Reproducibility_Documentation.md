# Reproducibility Documentation

## Current evidence level

The public Supplementary package supports **reported-output verification**, not a portable full raw-source rerun. The coordinate-free metric files permit direct recalculation of the baseline NI-EA field, comparators, interaction and weighting scenarios, matched road-network score fields, official-source sensitivity, DEWA geometry/weight mechanism decomposition, and Pareto fields. Detailed public enrichment rows also permit re-aggregation of the published enrichment summaries and ranges.

The public package does **not** contain the raw third-party candidate, amenity, charger, substation, DEWA, boundary, or road-network inputs. It therefore cannot recreate candidate admission, self-excluded activity-density counts, spatial distances, routes, regular-grid node scores, or original source hashes. The regular-grid and enrichment work remains verifiable at public output-summary level only until a controlled source archive is supplied.

## Runtime environment

The archived execution environment used Python 3.11, pandas 2.2.2, NumPy 1.26.4, SciPy 1.12.0, NetworkX 3.2.1, GeoPandas 0.14.4, Shapely 2.0.3, pyrosm 0.6.2, and scikit-learn 1.4.2.

## Controlled-rerun requirement

A future controlled rerun must satisfy the intake specification in `controlled_rerun_intake/`, preserve immutable record identifiers, resolve the nine self-exclusion discrepancies at record level, and regenerate every reported source-dependent output in a clean environment. Until that rerun passes, the study must not be described as fully source-to-result reproducible.
