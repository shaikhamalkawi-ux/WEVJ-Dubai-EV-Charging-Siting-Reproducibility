# Field terminology mapping

No numerical value was altered. The following field labels were changed solely to disclose the construct correctly.

| Previous field label | Corrected field label | Meaning |
|---|---|---|
| `demand_poi_1km` | `candidate_derived_activity_density_count_1km_self_excluded` | Self-excluded local count of other admitted candidate/amenity records within 1 km. |
| `demand_poi_within_1km_self_excluded` | `candidate_derived_activity_density_count_1km_self_excluded` | Same construct in the matched road-network output. |
| `demand_norm` | `activity_density_norm` | Direct min--max normalized activity-density count. |
| `I_DemandGrid` | `I_ActivityDensityGrid` | Product of normalized activity-density and grid-access values. |
| `w_demand` | `w_activity_density` | CRITIC or comparator weight for the candidate-derived activity-density criterion. |

These fields are not observed charging demand, an independent demand layer, or operational validation.
