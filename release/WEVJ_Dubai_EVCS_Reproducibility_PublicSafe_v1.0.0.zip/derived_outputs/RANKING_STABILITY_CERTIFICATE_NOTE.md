# Ranking-Stability Certificate Note

This file documents the three-level ranking-stability certificate reported in the ranking-stability supplement. The certificate is computed from already reported sensitivity outputs and does not introduce any new score, criterion, source layer, weight, or ranking.

Definitions:
- Omega_15: top-15 retention fraction.
- L: leader-retention indicator.
- F: exact full-order retention fraction, computed as 1 - changed_rank_count / n_s.

The certificate supports the manuscript claim boundary: the Dubai case provides source- and proxy-sensitive top-tier screening evidence, not a source-invariant final siting decision.
